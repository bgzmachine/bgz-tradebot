# BGZ TradeBot

A simulation-based trading bot running on Render.